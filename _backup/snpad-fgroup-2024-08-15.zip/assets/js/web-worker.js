const URL_TRANSLATE_TO_CODE     = "/translate-to-code";
const URL_TRANSLATE_FROM_CODE   = "/translate-from-code";
const URL_UPDATE_PASSKEY   = "/update-passkey";
const URL_VIEW = "";
const URL_TINY_URL_API = "https://tinyurl.com/api-create.php?url=";

$( document ).ready(function() {
    console.log( "ready!" );

    $('#send-note').on('click', function(){
        let qcodeNa = $('#qcode').val();
        let passkeyNa = $('#no-wa-target-sharing').val();

        let snpadURL = window.location.origin + '/view?q=' + qcodeNa;
        let shortURLNa = convertToShort(snpadURL);


        let dataForm = {q : qcodeNa, passkey : passkeyNa, shorturl: shortURLNa};
        console.log('mengirim ' + passkeyNa + ' ' + qcodeNa + ' to ' + URL_UPDATE_PASSKEY);

        updatePassKey(dataForm, URL_UPDATE_PASSKEY);
    	
    });

     $('#btn-open-access').on('click', function(){
        let pass = $('#passkey').val();
        let code = $('#text-content').text();
        let q = $('#q').val();

          $('.wait-message').show();
          $('.access-message').hide();

        // call the system for opening the data
        // after 3 seconds
        setTimeout(function(){
               
               requestAccess(q, pass, code, URL_TRANSLATE_FROM_CODE);
        }, 3000);

       
    });

    $('#btn-translate').on('click', function(){
    	
        $('#btn-open-access').hide();
    	$('.error-message').hide();
        $('.wait-message').hide();
        $('.access-message').show();

    });

      $('#btn-clear').on('click', function(){
        
      $('.ql-editor').html('');
      $('#qcode').val('');

    });

    $('#secure-note').on('click', function(){
        
        $('#send-note').hide(); 
        $('.another-message').hide();
        $('.error-message').hide();

        let textNa = $('.ql-editor').html();
        let dataNa = {text : textNa};

        // call the system for securing the data
        // after 3 seconds
        setTimeout(function(){
                sendData(dataNa, URL_TRANSLATE_TO_CODE);
        }, 3000);
        

    });

    $('#no-wa-target-sharing').keyup(function() {
      if ($(this).val().trim() === '') {
        $('#send-note').hide(); 
      } else {
        $('#send-note').show(); 
      }
    });

    $('#passkey').keyup(function() {
      if ($(this).val().trim() === '') {
        $('#btn-open-access').hide(); 
      } else {
        $('#btn-open-access').show(); 
      }
    });


});

function sendIntoWA(aShortedURL){

    // https://api.whatsapp.com/send?phone=1111111111&text=Hi
    let phone = $('#no-wa-target-sharing').val();
    phone = phone.replace(/-/g, "");
    phone = phone.replace(/^08/, "628");
    phone = phone.replace("62 8","628");
    phone = phone.replace(" ", "");
    phone = phone.replace("+", "");

    let text = '*Check Pesanku* di ' + aShortedURL + ' ya!';
    let url = "https://api.whatsapp.com/send?phone=" + phone + "&text=" + encodeURI(text);
    window.location = url;

}
    
function convertToShort(urlNa){

    let targetURL = URL_TINY_URL_API + urlNa;
    let result  = '';

    $.ajax({
        url: targetURL,
        async: false,
        cache : false,
        type: 'GET',
        success: function(data){
           result = data;
        }
    });

    return result;

}

function updatePassKey(dataNa, urlNa){
let shortURL = dataNa.shorturl;

    $.ajax({
        url: urlNa,
        data: (dataNa),
        cache : false,
        type: 'POST',
        success: function(data){
            console.log(data);
            
            if(data == 'success'){
                sendIntoWA(shortURL);
            }

        }
    });

}

function requestAccess(qNa, dataPass, codeNa, urlNa){

let dataForm = {q : qNa, passkey : dataPass, code : codeNa};

console.log('mengirim ' + dataPass + ' to ' + urlNa);

    $.ajax({
        url: urlNa,
        data: (dataForm),
        cache : false,
        type: 'POST',
        success: function(data){
            console.log(data);
            let dataIn = JSON.parse(data);
            if(dataIn.status == 'success'){
              
              $('#text-content').html(dataIn.data);
              $('#text-content').data('status', 'decrypted');
              $('#btn-translate').hide();
              $('#title').text('Decrypted:');

              // close the modal
              $('#passkeyForm').modal('hide');
            }else{
                $('.error-message').show();
                $('.wait-message').hide();
                  $('#btn-open-access').hide(); 
            }
        }
    });

}


function sendData(dataForm, urlNa){

console.log('mengirim ' + dataForm + ' to ' + urlNa);

    $.ajax({
        url: urlNa,
        data: (dataForm),
        cache : false,
        type: 'POST',
        success: function(data){
            console.log(data);
            let dataIn = JSON.parse(data);
            if(dataIn.status == 'success'){
                $('#qcode').val(dataIn.q);
                $('.ql-editor').html(dataIn.data);
                $('.another-message').show();
                $('#wait-message').hide();

            }else{
                $('.error-message').show();
                $('#wait-message').hide();
            }
        }
    });

}