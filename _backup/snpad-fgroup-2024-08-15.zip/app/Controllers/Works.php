<?php

namespace App\Controllers;

use CodeIgniter\Files\File;
use App\Models\DataModel;

class Works extends BaseController
{
	
	protected $helpers = ['form', 'filesystem', 'directory'];
	
	private function generateDigitRandom($manyDigit){
		
		$X = $manyDigit;
	
	$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$generatedString = '';
	$charactersLength = strlen($characters);
	$angka1 = mt_rand(0, 9);
	$angka2 = mt_rand(0, 9);
	
	for ($i = 0; $i < $X; $i++) {
			
			$generatedString .= $characters[rand(0, $charactersLength - 1)];			
		}
		
		return $generatedString ;
	}
	
	private function renameFile($first, $last){
		
		$stat = false;
		
		if (rename($first, $last)) {
            $stat = true;
        } 
		
		return $stat;
		
	}
	
	public function displayFile(){
		
		$idGiven = $this->request->getGet('q');
		
		$filename = $idGiven . ".snpad";
		
		// pass the reference into Model (DB)
		$model = new DataModel();
		
		$result = $model->selectData($filename);
		
		if($result !== null){
			$foldername = WRITEPATH . "uploads/" . $result[0]->folder; 
			$konten = file_get_contents($foldername . "/" . $filename);
			
			$data = array(
				'konten' => $konten,
				'q' => $idGiven
			);

			return view('viewer_page', $data);
		}
		
		
		echo "failed!";
	}
	
	private function convertShortURL($url) {
	
		return file_get_contents('http://tinyurl.com/api-create.php?url='.$url);
	
	}
	
	private function getOS() {
	$userAgent = $_SERVER['HTTP_USER_AGENT'];	
		
    $osList = [
        'Windows' => '(Windows NT|WinNT|Win16)',
        'Linux' => '(Linux|X11)',
        'Mac' => '(Mac_PowerPC|Macintosh|Mac)',
        'Unix' => '(UNIX)',
        'BSD' => '(BSD)',
        'Android' => '(Android)',
        'iOS' => '(iPhone|iPad|iPod)'
    ];
    foreach ($osList as $os => $pattern) {
        if (preg_match('/' . $pattern . '/i', $userAgent)) {
            return $os;
        }
    }
	
    return 'Unknown';

}
		
    public function sendFile()
    {

        $fileNa = $this->request->getFile('dokumen');

        if (! $fileNa->hasMoved()) {
			
			$dirPath = WRITEPATH . 'uploads/';
            $filepath =  $dirPath . $fileNa->store();
			$sevenDigitKode = $this->generateDigitRandom(7);
			$filerenamed = $sevenDigitKode . ".snpad";
			
			$newName = $fileNa->getTempName() . "/" . $filerenamed;

            $data = ['uploaded_fileinfo' => new File($filepath)];
			
			$this->renameFile($filepath, $newName);

			// pass the reference into Model (DB)
			$model = new DataModel();
		
			$ip = $this->request->getIPAddress();
			$os = $this->getOS();
			$fd = basename(rtrim($fileNa->getTempName(), "/"));
		
			$insertData = array(
				'folder' => $fd,
				'filename' => $filerenamed,
				'ip_address' => $ip,
				'os' 		=> $os
			);
			
			$insertedId = $model->insertData($insertData);
			
            //echo "Success!";
        }

        $aURL = "https://snpad.fgroupindonesia.com/view/?q=" . $sevenDigitKode;
        $finalURL = $this->convertShortURL($aURL);

 		$data = [
            'url' => $finalURL,
            'origin_url' => $aURL
        ];

         $this->response->setContentType('application/json');
         echo json_encode($data);

		//echo "<br> /?q=" . $sevenDigitKode;
		
       // $data = ['errors' => 'The file has already been moved.'];
	   //echo "<br>" . var_dump($data);
    }

    private static $secretKey = "MySecretKey";
    private static $salt = "MySalt";
    private static $keyLength = 256;
    private static $iterationCount = 65536;

	public function translate_to_code() {
		$someText = $this->request->getPost('text');

        $encrypted = $this->encrypt($someText, self::$secretKey, self::$salt);
        // return $encrypted;


 		// we store this message on both server (folder)
 		// and also DB (on the server)
 			$dateNow = date('Ymd');
 			$dirPath = WRITEPATH . 'uploads/';
            $filepath =  $dirPath . '/' . $dateNow;

			$sevenDigitKode = $this->generateDigitRandom(7);
			$filerenamed = $sevenDigitKode . ".snpad";
			
			$completePath = $filepath . '/' . $filerenamed;
			//echo $completePath;

			if (!is_dir($filepath)) {
			    mkdir($filepath, 0777, true);
			 }

			  // Create the file inside the directory
			  file_put_contents($completePath, $encrypted);

			// pass the reference into Model (DB)
			$model = new DataModel();
		
			$ip = $this->request->getIPAddress();
			$os = $this->getOS();
			$fd = $dateNow;
		
			$insertData = array(
				'folder' => $fd,
				'filename' => $filerenamed,
				'ip_address' => $ip,
				'os' 		=> $os
			);
			
			$insertedId = $model->insertData($insertData);

        $result = array(
        	'status' => 'success',
        	'data' => $encrypted,
        	'q' => $sevenDigitKode
        );

       echo json_encode($result);

    }

    public function update_passkey(){

    	$q = $this->request->getPost('q');
    	$pass = $this->request->getPost('passkey');
    	$fname = $q . ".snpad";

    	$data = array(
    		'passkey' => $pass
    	);

    	// pass the reference into Model (DB)
		$model = new DataModel();

		$dataRaw = $model->selectData($fname);
		$id = $dataRaw[0]->id;

		$resultData = $model->updateData($id, $data);

		if($resultData > 0){
			echo "success";
		}else{
			echo "none";
		}
		
    }

    public function translate_from_code() {
    	$someCode = $this->request->getPost('code');
    	$q = $this->request->getPost('q');
    	$pass = $this->request->getPost('passkey');

    	$filename = $q . ".snpad";
    	

    	// pass the reference into Model (DB)
			$model = new DataModel();

		$resultData = $model->selectData($filename);
		$mayWork = false;

		if($resultData != false){
			if($resultData[0]->passkey == $pass){
				$mayWork = true;
			}
		}


		if($mayWork){

		$decrypted = $this->decrypt($someCode, self::$secretKey, self::$salt);
        //return $decrypted;
    
	 		$result = array(
	        	'status' => 'success',
	        	'data' => $decrypted
	        );

		}else{
			$result = array(
	        	'status' => 'failed',
	        	'data' => 'none'
	        );
		}
        

        echo json_encode($result);

    }

    private function encrypt($strToEncrypt, $secretKey, $salt) {
        $iv = openssl_random_pseudo_bytes(16);
        $ivspec = $iv;

        $key = hash_pbkdf2("sha256", $secretKey, $salt, self::$iterationCount, self::$keyLength / 8, true);
        $cipher = "AES-256-CBC";
        $options = 0;

        $encrypted = openssl_encrypt($strToEncrypt, $cipher, $key, $options, $ivspec);
        $encryptedData = $iv . $encrypted;
        return base64_encode($encryptedData);
    }

    private function decrypt($strToDecrypt, $secretKey, $salt) {
        $encryptedData = base64_decode($strToDecrypt);
        $iv = substr($encryptedData, 0, 16);
        $cipherText = substr($encryptedData, 16);

        $key = hash_pbkdf2("sha256", $secretKey, $salt, self::$iterationCount, self::$keyLength / 8, true);
        $cipher = "AES-256-CBC";
        $options = 0;

        $decrypted = openssl_decrypt($cipherText, $cipher, $key, $options, $iv);
        return $decrypted;
    }


}
