<html>
<head>
<title>Keren Upload</title>
</head>

<body>
<form action="/post" method="post" enctype="multipart/form-data" >
<h2>Contoh Upload</h2>
<input type="file" name="dokumen" />
<input type="submit" value="Kirim" />
</form>

</body>

</html>