<link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

<link rel='stylesheet' href='/assets/css/style.css' />
<link rel='stylesheet' href='/assets/css/quill.snow.css' />

<link rel="stylesheet" href="/assets/css/font-awesome.min.css">

<link rel='stylesheet' href='/assets/vendor/bootstrap/css/bootstrap.css' />


<script src="/assets/js/quill.js"></script>
<script src="/assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<script src="/assets/js/jquery-3.7.1.min.js"></script>
<script src="/assets/js/web-worker.js"></script>


<body class='centered'>

<?php include('modal_share_note.php'); ?>

<div id="container-logo">
<a href="http://snpad.fgroupindonesia.com">
<img class="logo24" src="/assets/img/logo-snpad.png" />
</a>
</div>

<h3 id="title-encrypted" >Write Your Notes:</h3>
<br>
<center>
<div class='fit medium-note' id='writepad'>  </div>
</center>
<input id="secure-note" type='button' data-bs-toggle="modal" data-bs-target="#exampleModal" value='Secure &amp; Share this!' class=' btn-primary btn-translate' />
<input id="btn-clear" type='button' value='Clear All' class='btn-primary ' />

<script>
  const quill = new Quill('#writepad', {
    theme: 'snow'
  });
</script>

<input type="hidden" id="qcode" name="q" value="">

</body>