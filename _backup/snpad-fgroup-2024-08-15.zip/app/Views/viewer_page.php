<link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

<link rel='stylesheet' href='/assets/vendor/bootstrap/css/bootstrap.css' />
<link rel='stylesheet' href='assets/css/style.css' />

<script src="/assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<script src="/assets/js/jquery-3.7.1.min.js"></script>
<script src="/assets/js/web-worker.js"></script>

<body class='centered'>

<div id="container-logo">
<a href="http://snpad.fgroupindonesia.com">
<img class="logo24" src="assets/img/logo-snpad.png" />
</a>
</div>

<?php include('modal_passkey_form.php'); ?>

<h3 id="title" >Encrypted:</h3>
<br>
<input type="hidden" id="q" name="q" value="<?= $q; ?>" >
<div class='fit' id="text-content" data-status="encrypted" >  <?=$konten ;?>  </div>

<input type='button' data-bs-toggle="modal" data-bs-target="#passkeyForm"  id="btn-translate" value='translate this!' class='btn-primary btn-translate' />

</body>