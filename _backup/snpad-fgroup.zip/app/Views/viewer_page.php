<link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

<link rel='stylesheet' href='assets/css/style.css' />

<body class='centered'>

<div id="container-logo">
<a href="http://snpad.fgroupindonesia.com">
<img class="logo24" src="assets/img/logo-snpad.png" />
</a>
</div>

<h3 id="title-encrypted" >Encrypted:</h3>
<br>
<div class='fit'>  <?=$konten ;?>  </div>

<input type='button' value='translate this!' class='btn-primary btn-translate' />

</body>