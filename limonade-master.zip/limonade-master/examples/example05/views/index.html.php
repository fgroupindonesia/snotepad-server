<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

<?php content_for('sidebar'); ?>
  <p><em>This content is available in the layout with the 
    <code>$sidebar</code> variable</em></p>

  <ul>
    <li>Exeros quisque modiam aliquipsum facincilit min. </li>
    <li>Eliquatum amconsendre quatet aciliqu consecte lore. </li>
    <li>Dolum feugue faccum. </li>
    <li>Eui lan landignibh, feugiamet nullam modit volorerci, eros nosto sequam veliquisit.</li>
  </ul>

  <p><small>Enibh ullan utpationse turpis velisim ullut alismolum. </small></p>
<?php end_content_for(); ?>