<?php
define('TEST_LIB_A', true);
?>