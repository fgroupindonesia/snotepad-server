<?php
define('TEST_LIB_C', true);
?>