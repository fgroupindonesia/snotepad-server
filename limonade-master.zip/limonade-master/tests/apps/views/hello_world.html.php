<p>Hello World</p>
<?php if(isset($lorem)):?><p><?php echo $lorem; ?></p><?php endif; ?>